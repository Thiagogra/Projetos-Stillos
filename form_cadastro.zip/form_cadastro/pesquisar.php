<!--##########################  HTML ###############################-->

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">

        <div class="span10 offset1">
            <div class="row">
                <h3>Pesquisa Formandos</h3>
            </div>

            <br>

            <form class="form-horizontal" action="" method="post">

                <div class="control-group">

                    <div class="controls">
                        <label>Nome: </label>
                        
                        <input action="submit" type="text" id="meuValor" name="nameValor" value="<?php $valor; ?>" />
                        
                                               
                        <br><br>


                    </div>
                </div>



                <div class="form-actions">
                    <input name="SendPesqUser" type="submit" class=" btn btn-primary" value="Pesquisar">
                    <br>
                    <br>
                    <a class="btn btn-secondary" href="index.php">Voltar</a>
                </div>
            </form>
        </div>

        </div> <!-- /container -->


    <div class="container">
        <br>

        <div class="row">


            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>CPF</th>
                        <th>RG</th>
                        <th>UF</th>
                        <th>Data Cadastro</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php
                        
                        require 'database.php';
                        $pdo = Database::connect();
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $valor = filter_input(INPUT_POST, 'nameValor', FILTER_SANITIZE_STRING);
                        $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
                        $sql = "SELECT * FROM tb_formandos WHERE nome LIKE '%$valor%'";                                     
                               
                            if ($valor) {
                                                                             
                            foreach ($pdo->query($sql) as $row) {
                                echo '<tr>';
                                echo '<td>' . $row['nome'] . '</td>';
                                echo '<td>' . $row['email'] . '</td>';
                                echo '<td>' . $row['cpf'] . '</td>';
                                echo '<td>' . $row['rg'] . '</td>';
                                echo '<td>' . $row['uf_rg'] . '</td>';
                                echo '<td>' . $row['data_cadastro'] . '</td>';
                                echo '<td width=250>';
                                echo '<a class="btn btn-primary" href="read.php?id=' . $row['id'] . '">Ver</a>';
                                echo ' ';
                                echo '<a class="btn btn-success" href="update.php?id=' . $row['id'] . '">Atualizar</a>';
                                echo ' ';
                                echo '<a class="btn btn-danger" href="delete.php?id=' . $row['id'] . '">Deletar</a>';
                                echo '</td>';
                                echo '</tr>';
                            }
                        }if ($valor = null) {
                            
                        } 
                            Database::disconnect();                      
                                      
                    ?>

                </tbody>
            </table>
       
   
</body>

</html>