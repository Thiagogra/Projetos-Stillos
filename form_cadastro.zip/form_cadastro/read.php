<?php
require 'database.php';
$id = null;
if (!empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}

if (null == $id) {
    header("Location: index.php");
} else {
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM tb_formandos where id = ?";
    $q = $pdo->prepare($sql);
    $q->execute(array($id));
    $data = $q->fetch(PDO::FETCH_ASSOC);
    Database::disconnect();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">

        <div class="span10 offset1">
            <div class="row">
                <h3>Formando</h3>
            </div>

            <div class="form">


                <div class="control-group">
                    <label class="control-label">Nome</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['nome']; ?>
                        </label>
                    </div>
                </div>


                <div class="control-group">
                    <label class="control-label">Email</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['email']; ?>
                        </label>
                    </div>
                </div>


                <div class="control-group">
                    <label class="control-label">CPF</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['cpf']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">RG</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['rg']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">UF</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['uf_rg']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Data Cadastro</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['data_cadastro']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Endereço</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['endereco']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Número</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['numero']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Complemento</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['complemento']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">CEP</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['cep']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Bairro</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['bairro']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Cidade</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['cidade']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">UF</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['uf']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Fone Residencial</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['fone_residencial']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Fone Celular</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['fone_celular']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Altura</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['altura']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Data Nascimento</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['data_nascimento']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">RA</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['ra']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Entidade Ensino</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['entidade_ensino']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Curso</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['curso']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Semestre Conclusão</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['semestre_conclusao']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Ano</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['ano']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Campus</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['campus']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Sala</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['sala']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Prédio</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['predio']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Período</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['periodo']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Pai</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['pai']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Fone Pai</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['fone_pai']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Mãe</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['mae']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Fone Mãe</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['fone_mae']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Contato</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['contato']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Nome Contato</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['nome_contato']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Telefone Contato</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['telefone_contato']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Autorização</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['autorizacao']; ?>
                        </label>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Data Colação</label>
                    <div class="form-control col-md-3">
                        <label class="checkbox">
                            <?php echo $data['data_colacao']; ?>
                        </label>
                    </div>
                </div>





                <div class="form-actions">
                    <a style="margin-top: 10px;" class="btn btn-secondary" href="index.php">Voltar</a>
                </div>


            </div>
        </div>

    </div> <!-- /container -->
</body>

</html>