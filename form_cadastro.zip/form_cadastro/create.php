<?php

    require 'database.php';

    // ###########################  keep track validation errors ##################################

    if (!empty($_POST)) {

        $nomeError = null;
        $emailError = null;
        $cpfError = null;
        $rgError = null;
        $uf_rgError = null;
        $data_cadastroError = null;
        $endereco = null;
        $numero = null;
        $complemento = null;
        $cep = null;
        $bairro = null;
        $cidade = null;
        $uf = null;
        $fone_residencial = null;
        $fone_celular = null;
        $altura = null;
        $data_nascimento = null;
        $ra = null;
        $entidade_ensino = null;
        $curso = null;
        $semestre_conclusao = null;
        $ano = null;
        $campus =  null;
        $sala = null;
        $predio = null;
        $periodo = null;
        $pai = null;
        $fone_pai = null;
        $mae = null;
        $fone_mae = null;
        $contato = null;
        $nome_contato = null;
        $telefone_contato = null;
        $autorizacao = null;
        $data_colacao = null;
        $contrato_sistema_foto = null;
        $codigo_sistema = null;
        $codigo_contrato = null;
        $foto_real_formando = null;




    // #######################     keep track post values  ######################################################

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $cpf = $_POST['cpf'];
        $rg = $_POST['rg'];
        $uf_rg = $_POST['uf_rg'];
        $data_cadastro = $_POST['data_cadastro'];
        $endereco =  $_POST['endereco'];
        $numero = $_POST['numero'];
        $complemento = $_POST['complemento'];
        $cep =  $_POST['cep'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $uf = $_POST['uf'];
        $fone_residencial = $_POST['fone_residencial'];
        $fone_celular = $_POST['fone_celular'];
        $altura = $_POST['altura'];
        $data_nascimento = $_POST['data_nascimento'];
        $ra = $_POST['ra'];
        $entidade_ensino = $_POST['entidade_ensino'];
        $curso =  $_POST['curso'];
        $semestre_conclusao = $_POST['semestre_conclusao'];
        $ano = $_POST['ano'];
        $campus = $_POST['campus'];
        $sala = $_POST['sala'];
        $predio = $_POST['predio'];
        $periodo = $_POST['periodo'];
        $pai = $_POST['pai'];
        $fone_pai = $_POST['fone_pai'];
        $mae = $_POST['mae'];
        $fone_mae = $_POST['fone_mae'];
        $contato = $_POST['contato'];
        $nome_contato = $_POST['nome_contato'];
        $telefone_contato = $_POST['telefone_contato'];
        $autorizacao = $_POST['autorizacao'];
        $data_colacao = $_POST['data_colacao'];
        $contrato_sistema_foto = $_POST['contrato_sistema_foto'];
        $codigo_sistema = $_POST['codigo_sistema'];
        $codigo_contrato = $_POST['codigo_contrato'];
        $foto_real_formando = $_POST['foto_real_formando'];



            //   ###########################  validate input ########################################################

            $valid = true;
            if (empty($nome)) {
                $nomeError = 'Por Favor Digite o Nome';
                $valid = false;
            }

            if (empty($email)) {
                $emailError = 'Por Favor Digite o Email';
                $valid = false;
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailError = 'Por Favor Digite um Email Válido';
                $valid = false;
            }

            if (empty($cpf)) {
                $cpfError = 'Por Favor Digite um CPF';
                $valid = false;
            }


            // ############################  insert data  ###############################################

            if ($valid) {
                $pdo = Database::connect();
                $pdo ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "INSERT INTO tb_formandos (nome, email, cpf, rg, uf_rg, data_cadastro, endereco, numero, complemento, cep, bairro, cidade, uf, fone_residencial, fone_celular, altura, data_nascimento, ra, entidade_ensino, curso, semestre_conclusao, ano, campus, sala, predio, periodo, pai, fone_pai, mae, fone_mae, contato, nome_contato, telefone_contato, autorizacao, data_colacao, contrato_sistema_foto, codigo_sistema, codigo_contrato, foto_real_formando) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $q = $pdo->prepare($sql);
                $q ->execute(array($nome, $email, $cpf, $rg, $uf_rg, $data_cadastro, $endereco, $numero, $complemento, $cep, $bairro, $cidade, $uf, $fone_residencial, $fone_celular, $altura, $data_nascimento, $ra, $entidade_ensino, $curso, $semestre_conclusao, $ano, $campus, $sala, $predio, $periodo, $pai, $fone_pai, $mae, $fone_mae, $contato, $nome_contato, $telefone_contato, $autorizacao, $data_colacao, $contrato_sistema_foto, $codigo_sistema, $codigo_contrato, $foto_real_formando));
                Database::disconnect();
                header("Location: index.php");
            }
}


?>

<!--################################ HTML #############################################################-->

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">

        <div>



            <div class="row">

                <h3 style="margin-top: 10px;">Cadastro de Formandos</h3>
            </div>

            <br>

            <div class="form-actions">
                <a class="btn btn-secondary" href="index.php">Voltar</a>
            </div>

            <br>


            <form class="form-group " action="create.php" method="post">


                <div class="control-group <?php echo !empty($nomeError) ? 'error' : ''; ?>">

                    <label class="control-label">Nome</label>

                    <div class="controls">
                        <input name="nome" type="text" placeholder="Nome" value="<?php echo !empty($nome) ? $nome : ''; ?>">
                        <?php if (!empty($nomeError)) : ?>
                            <span class="help-inline"><?php echo $nomeError; ?></span>
                        <?php endif; ?>
                    </div>

                </div>

                <br>


                <div class="control-group <?php echo !empty($emailError) ? 'error' : ''; ?>">
                    <label class="control-label">Email</label>

                    <div class="controls">
                        <input name="email" type="text" placeholder="Email" value="<?php echo !empty($email) ? $email : ''; ?>">
                        <?php if (!empty($emailError)) : ?>
                            <span class="help-inline"><?php echo $emailError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($cpfError) ? 'error' : ''; ?>">
                    <label class="control-label">CPF</label>
                    <div class="controls">
                        <input name="cpf" type="text" placeholder="CPF" value="<?php echo !empty($cpf) ? $cpf : ''; ?>">
                        <?php if (!empty($cpfError)) : ?>
                            <span class="help-inline"><?php echo $cpfError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>



                <div class="control-group <?php echo !empty($rgError) ? 'error' : ''; ?>">
                    <label class="control-label">RG</label>
                    <div class="controls">
                        <input name="rg" type="text" placeholder="RG" value="<?php echo !empty($rg) ? $rg : ''; ?>">
                        <?php if (!empty($rgError)) : ?>
                            <span class="help-inline"><?php echo $rgError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($uf_rgError) ? 'error' : ''; ?>">
                    <label class="control-label">UF</label>
                    <div class="controls">
                        <input name="uf_rg" type="text" placeholder="UF" value="<?php echo !empty($uf_rg) ? $uf_rg : ''; ?>">
                        <?php if (!empty($uf_rgError)) : ?>
                            <span class="help-inline"><?php echo $uf_rgError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($data_cadastroError) ? 'error' : ''; ?>">
                    <label class="control-label">Data Cadastro</label>
                    <div class="controls">
                        <input name="data_cadastro" type="text" placeholder="Data Cadastro" value="<?php echo !empty($data_cadastro) ? $data_cadastro : ''; ?>">
                        <?php if (!empty($data_cadastroError)) : ?>
                            <span class="help-inline"><?php echo $data_cadastroError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($enderecoError) ? 'error' : ''; ?>">
                    <label class="control-label">Endereço</label>
                    <div class="controls">
                        <input name="endereco" type="text" placeholder="Endereço" value="<?php echo !empty($endereco) ? $endereco : ''; ?>">
                        <?php if (!empty($enderecoError)) : ?>
                            <span class="help-inline"><?php echo $enderecoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($numeroError) ? 'error' : ''; ?>">
                    <label class="control-label">Numero</label>
                    <div class="controls">
                        <input name="numero" type="text" placeholder="Numero" value="<?php echo !empty($numero) ? $numero : ''; ?>">
                        <?php if (!empty($numeroError)) : ?>
                            <span class="help-inline"><?php echo $numeroError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($complementoError) ? 'error' : ''; ?>">
                    <label class="control-label">Complemento</label>
                    <div class="controls">
                        <input name="complemento" type="text" placeholder="Complemento" value="<?php echo !empty($complemento) ? $complemento : ''; ?>">
                        <?php if (!empty($complementoError)) : ?>
                            <span class="help-inline"><?php echo $complementoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($ceoError) ? 'error' : ''; ?>">
                    <label class="control-label">CEP</label>
                    <div class="controls">
                        <input name="cep" type="text" placeholder="CEP" value="<?php echo !empty($cep) ? $cep : ''; ?>">
                        <?php if (!empty($cepError)) : ?>
                            <span class="help-inline"><?php echo $cepError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($bairroError) ? 'error' : ''; ?>">
                    <label class="control-label">Bairro</label>
                    <div class="controls">
                        <input name="bairro" type="text" placeholder="Bairro" value="<?php echo !empty($bairro) ? $bairro : ''; ?>">
                        <?php if (!empty($bairroError)) : ?>
                            <span class="help-inline"><?php echo $bairroError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($cidadeError) ? 'error' : ''; ?>">
                    <label class="control-label">Cidade</label>
                    <div class="controls">
                        <input name="cidade" type="text" placeholder="Cidade" value="<?php echo !empty($cidade) ? $cidade : ''; ?>">
                        <?php if (!empty($cidadeError)) : ?>
                            <span class="help-inline"><?php echo $cidadeError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($ufError) ? 'error' : ''; ?>">
                    <label class="control-label">UF</label>
                    <div class="controls">
                        <input name="uf" type="text" placeholder="UF" value="<?php echo !empty($uf) ? $uf : ''; ?>">
                        <?php if (!empty($ufError)) : ?>
                            <span class="help-inline"><?php echo $ufError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($fone_residencialError) ? 'error' : ''; ?>">
                    <label class="control-label">Fone Residencial</label>
                    <div class="controls">
                        <input name="fone_residencial" type="text" placeholder="Fone Residencial" value="<?php echo !empty($fone_residencial) ? $fone_residencial : ''; ?>">
                        <?php if (!empty($fone_residencialError)) : ?>
                            <span class="help-inline"><?php echo $fone_residencialError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($fone_celularError) ? 'error' : ''; ?>">
                    <label class="control-label">Fone Celular</label>
                    <div class="controls">
                        <input name="fone_celular" type="text" placeholder="Fone Celular" value="<?php echo !empty($fone_celular) ? $fone_celular : ''; ?>">
                        <?php if (!empty($fone_celularError)) : ?>
                            <span class="help-inline"><?php echo $fone_celularError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($alturaError) ? 'error' : ''; ?>">
                    <label class="control-label">Altura</label>
                    <div class="controls">
                        <input name="altura" type="text" placeholder="Altura" value="<?php echo !empty($altura) ? $altura : ''; ?>">
                        <?php if (!empty($alturaError)) : ?>
                            <span class="help-inline"><?php echo $alturaError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($data_nascimentoError) ? 'error' : ''; ?>">
                    <label class="control-label">Data Nascimento</label>
                    <div class="controls">
                        <input name="data_nascimento" type="text" placeholder="Data Nascimento" value="<?php echo !empty($data_nascimento) ? $data_nascimento : ''; ?>">
                        <?php if (!empty($data_nascimentoError)) : ?>
                            <span class="help-inline"><?php echo $data_nascimentoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($raError) ? 'error' : ''; ?>">
                    <label class="control-label">RA</label>
                    <div class="controls">
                        <input name="ra" type="text" placeholder="RA" value="<?php echo !empty($ra) ? $ra : ''; ?>">
                        <?php if (!empty($raError)) : ?>
                            <span class="help-inline"><?php echo $raError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($entidade_ensinoError) ? 'error' : ''; ?>">
                    <label class="control-label">Entidade Ensino</label>
                    <div class="controls">
                        <input name="entidade_ensino" type="text" placeholder="Entidade Ensino" value="<?php echo !empty($entidade_ensino) ? $entidade_ensino : ''; ?>">
                        <?php if (!empty($entidade_ensinoError)) : ?>
                            <span class="help-inline"><?php echo $entidade_ensinoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($cursoError) ? 'error' : ''; ?>">
                    <label class="control-label">Curso</label>
                    <div class="controls">
                        <input name="curso" type="text" placeholder="Curso" value="<?php echo !empty($curso) ? $curso : ''; ?>">
                        <?php if (!empty($cursoError)) : ?>
                            <span class="help-inline"><?php echo $cursoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>


                <br>

                <div class="control-group <?php echo !empty($semestre_conclusaoError) ? 'error' : ''; ?>">
                    <label class="control-label">Semestre Conclusao</label>
                    <div class="controls">
                        <input name="semestre_conclusao" type="text" placeholder="Semestre Conclusão" value="<?php echo !empty($semestre_conclusao) ? $semestre_conclusao : ''; ?>">
                        <?php if (!empty($semestre_conclusaoError)) : ?>
                            <span class="help-inline"><?php echo $semestre_conclusaoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($anoError) ? 'error' : ''; ?>">
                    <label class="control-label">Ano</label>
                    <div class="controls">
                        <input name="ano" type="text" placeholder="Ano" value="<?php echo !empty($ano) ? $ano : ''; ?>">
                        <?php if (!empty($anoError)) : ?>
                            <span class="help-inline"><?php echo $anoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($campusError) ? 'error' : ''; ?>">
                    <label class="control-label">Campus</label>
                    <div class="controls">
                        <input name="campus" type="text" placeholder="Campus" value="<?php echo !empty($campus) ? $campus : ''; ?>">
                        <?php if (!empty($campusError)) : ?>
                            <span class="help-inline"><?php echo $campusError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($salaError) ? 'error' : ''; ?>">
                    <label class="control-label">Sala</label>
                    <div class="controls">
                        <input name="sala" type="text" placeholder="Sala" value="<?php echo !empty($sala) ? $sala : ''; ?>">
                        <?php if (!empty($salaError)) : ?>
                            <span class="help-inline"><?php echo $salaError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($predioError) ? 'error' : ''; ?>">
                    <label class="control-label">Predio</label>
                    <div class="controls">
                        <input name="predio" type="text" placeholder="Predio" value="<?php echo !empty($predio) ? $predio : ''; ?>">
                        <?php if (!empty($predioError)) : ?>
                            <span class="help-inline"><?php echo $predioError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($periodoError) ? 'error' : ''; ?>">
                    <label class="control-label">Período</label>
                    <div class="controls">
                        <input name="periodo" type="text" placeholder="Periodo" value="<?php echo !empty($periodo) ? $periodo : ''; ?>">
                        <?php if (!empty($periodoError)) : ?>
                            <span class="help-inline"><?php echo $periodoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($paiError) ? 'error' : ''; ?>">
                    <label class="control-label">Pai</label>
                    <div class="controls">
                        <input name="pai" type="text" placeholder="Pai" value="<?php echo !empty($pai) ? $pai : ''; ?>">
                        <?php if (!empty($paiError)) : ?>
                            <span class="help-inline"><?php echo $paiError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($fone_paiError) ? 'error' : ''; ?>">
                    <label class="control-label">Fone Pai</label>
                    <div class="controls">
                        <input name="fone_pai" type="text" placeholder="Fone Pai" value="<?php echo !empty($fone_pai) ? $fone_pai : ''; ?>">
                        <?php if (!empty($fone_paiError)) : ?>
                            <span class="help-inline"><?php echo $fone_paiError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>



                <div class="control-group <?php echo !empty($maeError) ? 'error' : ''; ?>">
                    <label class="control-label">Mãe</label>
                    <div class="controls">
                        <input name="mae" type="text" placeholder="Mãe" value="<?php echo !empty($mae) ? $mae : ''; ?>">
                        <?php if (!empty($maeError)) : ?>
                            <span class="help-inline"><?php echo $maeError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($fone_maeError) ? 'error' : ''; ?>">
                    <label class="control-label">Fone Mãe</label>
                    <div class="controls">
                        <input name="fone_mae" type="text" placeholder="Fone mãe" value="<?php echo !empty($fone_mae) ? $fone_mae : ''; ?>">
                        <?php if (!empty($fone_maeError)) : ?>
                            <span class="help-inline"><?php echo $fone_maeError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($contatoError) ? 'error' : ''; ?>">
                    <label class="control-label">Contato</label>
                    <div class="controls">
                        <input name="contato" type="text" placeholder="Contato" value="<?php echo !empty($contato) ? $contato : ''; ?>">
                        <?php if (!empty($contatoError)) : ?>
                            <span class="help-inline"><?php echo $contatoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($nome_contatoError) ? 'error' : ''; ?>">
                    <label class="control-label">Nome Contato</label>
                    <div class="controls">
                        <input name="nome_contato" type="text" placeholder="Nome Contato" value="<?php echo !empty($nome_contato) ? $nome_contato : ''; ?>">
                        <?php if (!empty($nome_contatoError)) : ?>
                            <span class="help-inline"><?php echo $nome_contatoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($telefone_contatoError) ? 'error' : ''; ?>">
                    <label class="control-label">Telefone Contato</label>
                    <div class="controls">
                        <input name="telefone_contato" type="text" placeholder="Telefone Contato" value="<?php echo !empty($telefone_contato) ? $telefone_contato : ''; ?>">
                        <?php if (!empty($telefone_contatoError)) : ?>
                            <span class="help-inline"><?php echo $telefone_contatoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>


                <br>

                <div class="control-group <?php echo !empty($autorizacaoError) ? 'error' : ''; ?>">
                    <label class="control-label">Autorização</label>
                    <div class="controls">
                        <input name="autorizacao" type="text" placeholder="Autorizacao" value="<?php echo !empty($autorizacao) ? $autorizacao : ''; ?>">
                        <?php if (!empty($autorizacaoError)) : ?>
                            <span class="help-inline"><?php echo $autorizacaoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($data_colacaoError) ? 'error' : ''; ?>">
                    <label class="control-label">Data Colação</label>
                    <div class="controls">
                        <input name="data_colacao" type="text" placeholder="Data Colação" value="<?php echo !empty($data_colacao) ? $data_colacao : ''; ?>">
                        <?php if (!empty($data_colacaoError)) : ?>
                            <span class="help-inline"><?php echo $data_colacaoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br> 

             
               <div class="control-group<?php echo !empty($contrato_sistema_fotoError) ? 'error' : ''; ?>">
                    <label class="control-label">Contrato Sistema Foto</label>
                    <div class="controls">
                        <input name="contrato_sistema_foto" type="text" placeholder="Contrato Sistema Foto" value="<?php echo !empty($contrato_sistema_foto) ? $contrato_sistema_foto : ''; ?>">
                        <?php if (!empty($contrato_sistema_fotoError)) : ?>
                            <span class="help-inline"><?php echo $contrato_sistema_fotoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="control-group <?php echo !empty($codigo_sistemaError) ? 'error' : ''; ?>">
                    <label class="control-label">Codigo Sistema</label>
                    <div class="controls">
                        <input name="codigo_sistema" type="text" placeholder="Codigo Sistema" value="<?php echo !empty($codigo_sistema) ? $codigo_sistema : ''; ?>">
                        <?php if (!empty($codigo_sistemaError)) : ?>
                            <span class="help-inline"><?php echo $codigo_sistemaError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>


                <div class="control-group <?php echo !empty($codigo_contratoError) ? 'error' : ''; ?>">
                    <label class="control-label">Codigo Contrato</label>
                    <div class="controls">
                        <input name="codigo_contrato" type="text" placeholder="Codigo Contrato" value="<?php echo !empty($codigo_contrato) ? $codigo_contrato : ''; ?>">
                        <?php if (!empty($codigo_contratoError)) : ?>
                            <span class="help-inline"><?php echo $codigo_contratoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>


                <br>

                <div class="control-group <?php echo !empty($foto_real_formandoError) ? 'error' : ''; ?>">
                    <label class="control-label">Foto Real Formando</label>
                    <div class="controls">
                        <input name="foto_real_formando" type="text" placeholder="Foto Real Formando" value="<?php echo !empty($foto_real_formando) ? $foto_real_formando : ''; ?>">
                        <?php if (!empty($foto_real_formandoError)) : ?>
                            <span class="help-inline"><?php echo $foto_real_formandoError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <br>

                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Criar</button>
                    <a class="btn btn-secondary" href="index.php">Voltar</a>
                </div>
            </form>
        </div>
    </div> <!-- /container -->
</body>

</html>