<?php
require 'database.php';

$id = null;
if (!empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}

if (null == $id) {
    header("Location: index.php");
}

if (!empty($_POST)) {
    // keep track validation errors
    $nomeError = null;
    $emailError = null;
    $cpfError = null;
    $rgError = null;
    $uf_rgError = null;
    $data_cadastroError = null;

    // keep track post values
    $nomeError = null;
    $emailError = null;
    $cpfError = null;
    $rgError = null;
    $uf_rgError = null;
    $data_cadastroError = null;

    // validate input
    $valid = true;
    if (empty($nome)) {
        $nomeError = 'Por Favor Digite o Nome';
        $valid = false;
    }

    if (empty($email)) {
        $emailError = 'Por Favor Digite o Email';
        $valid = false;
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = 'Por Favor Digite um Email Válido';
        $valid = false;
    }

    if (empty($cpf)) {
        $cpfError = 'Por favor Digite um CPF Válido';
        $valid = false;
    }

    if (empty($rg)) {
        $rgError = 'Por favor Digite um RG Válido';
        $valid = false;
    }

    if (empty($uf_rg)) {
        $uf_rgError = 'Por favor Digite um Estado Válido';
        $valid = false;
    }

    if (empty($data_cadastro)) {
        $cpfError = 'Por favor Digite uma Data Válida';
        $valid = false;
    }

    // update data
    if ($valid) {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE tb_formandos  set nome = ?, email = ?, cpf =?, rg =?, uf_rg =?, data_cadastro =?  WHERE id = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($nome, $email, $cpf, $rg, $uf_rg, $data_cadastro, $id));
        Database::disconnect();
        header("Location: index.php");
    }
} else {
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM tb_formandos where id = ?";
    $q = $pdo->prepare($sql);
    $q->execute(array($id));
    $data = $q->fetch(PDO::FETCH_ASSOC);
    $name = $data['nome'];
    $email = $data['email'];
    $mobile = $data['cpf'];
    $mobile = $data['rg'];
    $mobile = $data['uf_rg'];
    $mobile = $data['data_cadastro'];
    Database::disconnect();
}
?>

<!-- ##############################  HTML ##################################-->

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">

        <div class="span10 offset1">
            <div class="row">
                <h3>Atualização de Cadastro</h3>
            </div>

            <form class="form-horizontal" action="update.php?id=<?php echo $id ?>" method="post">

                <div class="control-group <?php echo !empty($nomeError) ? 'error' : ''; ?>">
                    <label class="control-label">Nome</label>
                    <div class="controls">
                        <input name="nome" type="text" placeholder="Nome" value="<?php echo !empty($nome) ? $nome : ''; ?>">
                        <?php if (!empty($nomeError)) : ?>
                            <span class="help-inline"><?php echo $nomeError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="control-group <?php echo !empty($emailError) ? 'error' : ''; ?>">
                    <label class="control-label">Email</label>
                    <div class="controls">
                        <input name="email" type="text" placeholder="Email" value="<?php echo !empty($email) ? $email : ''; ?>">
                        <?php if (!empty($emailError)) : ?>
                            <span class="help-inline"><?php echo $emailError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="control-group <?php echo !empty($cpfError) ? 'error' : ''; ?>">
                    <label class="control-label">CPF</label>
                    <div class="controls">
                        <input name="cpf" type="text" placeholder="CPF" value="<?php echo !empty($cpf) ? $cpf : ''; ?>">
                        <?php if (!empty($cpfError)) : ?>
                            <span class="help-inline"><?php echo $cpfError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="control-group <?php echo !empty($rgError) ? 'error' : ''; ?>">
                    <label class="control-label">RG</label>
                    <div class="controls">
                        <input name="rg" type="text" placeholder="RG" value="<?php echo !empty($rg) ? $rg : ''; ?>">
                        <?php if (!empty($rgError)) : ?>
                            <span class="help-inline"><?php echo $rgError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="control-group <?php echo !empty($uf_rgError) ? 'error' : ''; ?>">
                    <label class="control-label">UF</label>
                    <div class="controls">
                        <input name="uf_rg" type="text" placeholder="UF" value="<?php echo !empty($uf_rg) ? $uf_rg : ''; ?>">
                        <?php if (!empty($uf_rgError)) : ?>
                            <span class="help-inline"><?php echo $uf_rgError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="control-group <?php echo !empty($data_cadastroError) ? 'error' : ''; ?>">
                    <label class="control-label">Data Cadastro</label>
                    <div class="controls">
                        <input name="data_cadastro" type="text" placeholder="Data Cadastro" value="<?php echo !empty($data_cadastro) ? $data_cadastro : ''; ?>">
                        <?php if (!empty($data_cadastroError)) : ?>
                            <span class="help-inline"><?php echo $data_cadastroError; ?></span>
                        <?php endif; ?>
                    </div>
                </div>





                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Atualizar</button>
                    <a class="btn" href="index.php">Voltar</a>
                </div>
            </form>
        </div>

    </div> <!-- /container -->
</body>

</html>